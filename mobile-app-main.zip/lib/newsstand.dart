import 'package:flutter/material.dart';
import 'package:my_grocery_app/app_drawer.dart';

class Newsstand extends StatefulWidget {
  const Newsstand({super.key});

  @override
  State<Newsstand> createState() => _NewsstandState();
}

class _NewsstandState extends State<Newsstand> {
  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Guitar Shop'),
        actions: [
          IconButton(
              onPressed: () {}, icon: const Icon(Icons.add_shopping_cart)),
        ],
        backgroundColor: Colors.white,
      ),
      drawer: AppDrawer(),
      body: Column(
        children: [
          // Header with Back Button
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey,
                  blurRadius: 5,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    '🎸 Featured Guitars',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('< Back'),
                ),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // Example Banner Image
          Container(
            width: double.infinity,
            height: 200,
            child: Image.asset(
              'lib/image/splashimage.png',
              fit: BoxFit.cover,
            ),
          ),

          const SizedBox(height: 20),

          // Expanded List of Featured Guitars
          Expanded(
            child: ListView(
              children: const [
                ListTile(
                  leading: Icon(Icons.music_note),
                  title: Text("Fender Stratocaster"),
                  subtitle: Text("Electric Guitar • New Arrival"),
                  trailing: Text("₱35,000"),
                ),
                Divider(),
                ListTile(
                  leading: Icon(Icons.music_note),
                  title: Text("Yamaha Acoustic"),
                  subtitle: Text("Acoustic Guitar • Best Seller"),
                  trailing: Text("₱12,000"),
                ),
                Divider(),
                ListTile(
                  leading: Icon(Icons.music_note),
                  title: Text("Ibanez RG Series"),
                  subtitle: Text("Electric Guitar • Limited Stock"),
                  trailing: Text("₱28,000"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
