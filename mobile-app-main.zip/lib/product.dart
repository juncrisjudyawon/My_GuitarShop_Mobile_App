class Product {
  final String id;
  final String name;
  final String vendor;
  final double price;
  final String image;
  bool isFavorite;

  Product({
    required this.id,
    required this.name,
    required this.vendor,
    required this.price,
    required this.image,
    this.isFavorite = false,
  });
}

final List<Product> products = [
  Product(
    id: '1',
    name: 'FenderStratocaster',
    price: 35000,
    vendor: 'Guitar Center',
    image: 'lib/image/fender.jpg',
  ),
  Product(
    id: '2',
    name: 'YamahaAcoustic',
    price: 12000,
    vendor: 'Music World',
    image: 'lib/image/acoustic.jpg',
  ),
  Product(
    id: '3',
    name: 'Gibson Les Paul',
    price: 50000,
    vendor: 'Guitar Hub',
    image: 'lib/image/gibson.jpg',
  ),
  Product(
    id: '4',
    name: 'Ibanez RG Series',
    price: 28000,
    vendor: 'Guitar Zone',
    image: 'lib/image/ibanez.jpg',
  ),
  Product(
    id: '5',
    name: 'PRS Custom 24',
    price: 45000,
    vendor: 'PRS Store',
    image: 'lib/image/prs.jpg',
  ),
  Product(
    id: '6',
    name: 'Taylor 21 Acoustic',
    price: 38000,
    vendor: 'Taylor Music',
    image: 'lib/image/taylor.jpg',
  ),
  Product(
    id: '7',
    name: 'Epiphone SG ',
    price: 22000,
    vendor: 'Music Planet',
    image: 'lib/image/epiphone.jpg',
  ),
  Product(
    id: '8',
    name: 'Jackson Dinky',
    price: 30000,
    vendor: 'Guitar Madness',
    image: 'lib/image/jackson.jpg',
  ),
  Product(
    id: '9',
    name: 'Cort X Series',
    price: 15000,
    vendor: 'Cort Shop',
    image: 'lib/image/cort.jpg',
  ),
];
