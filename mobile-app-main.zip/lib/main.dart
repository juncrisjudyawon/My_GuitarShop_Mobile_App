import 'package:flutter/material.dart';
import 'package:my_grocery_app/app_drawer.dart';
import 'package:my_grocery_app/cart.dart';
import 'package:my_grocery_app/info.dart';
import 'package:my_grocery_app/newsstand.dart';
import 'package:my_grocery_app/profile.dart';
import 'package:my_grocery_app/shop.dart';
import 'package:my_grocery_app/provider.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => CartProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Guitar Shop',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
      routes: {
        '/shop': (context) => const Shop(),
        '/newsstand': (context) => const Newsstand(),
        '/info': (context) => const Info(),
        '/cart': (context) => const Cart(),
        '/profile': (context) => const ProfilePage()
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      appBar: AppBar(title: const Text('Menu')),
      drawer: AppDrawer(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Welcome to My Guitar Shop!",
              style: TextStyle(
                fontSize: 22,
                color: Color(0xff070000),
                fontWeight: FontWeight.w600, // Semi-bold
                letterSpacing: 1.3, // Add spacing between letters
                fontStyle: FontStyle.italic, // Make it italic
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: 350,
              height: 250,
              color: Colors.red,
              child: Image.asset('lib/image/splashimage.png'),
            ),
            SizedBox(
              height: 20,
            ),
            ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/shop');
                },
                child: Text('Visit Shop')),
          ],
        ),
      ),
    );
  }
}
