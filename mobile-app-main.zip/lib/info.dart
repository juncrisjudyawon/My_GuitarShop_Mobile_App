import 'package:flutter/material.dart';
import 'package:my_grocery_app/app_drawer.dart';

class Info extends StatefulWidget {
  const Info({super.key});

  @override
  State<Info> createState() => _InfoState();
}

class _InfoState extends State<Info> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Who we are'),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.add_shopping_cart)),
        ],
        backgroundColor: Colors.white,
      ),
      drawer: AppDrawer(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ✅ Top Bar (KEPT from your design)
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey,
                    blurRadius: 5,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(child: Text('Who we are')),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('< Back'),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Welcome to My Guitar Shop!",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "We are passionate about music and dedicated to providing the best quality guitars and accessories to musicians of all levels.",
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 20),
                  Text("Our Mission",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text(
                    "Our mission is to make high-quality instruments affordable and accessible, while helping every musician grow and express their talent.",
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 20),
                  Text("What We Offer",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text("• Electric, Acoustic, and Bass Guitars",
                      style: TextStyle(fontSize: 16)),
                  Text("• Amplifiers and Pedals",
                      style: TextStyle(fontSize: 16)),
                  Text("• Guitar Accessories (Strings, Picks, Straps)",
                      style: TextStyle(fontSize: 16)),
                  Text("• Repairs and Maintenance",
                      style: TextStyle(fontSize: 16)),
                  Text("• Friendly and Expert Advice",
                      style: TextStyle(fontSize: 16)),
                  SizedBox(height: 20),
                  Text("Why Choose Us?",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text("• Trusted Brands (Fender, Yamaha, Gibson, Ibanez)",
                      style: TextStyle(fontSize: 16)),
                  Text("• Affordable Prices", style: TextStyle(fontSize: 16)),
                  Text("• Excellent Customer Service",
                      style: TextStyle(fontSize: 16)),
                  Text("• Passionate and Knowledgeable Staff",
                      style: TextStyle(fontSize: 16)),
                  SizedBox(height: 20),
                  Text("Contact Us",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text("📍 Poblacion one, Santiago Agusan Del Norte",
                      style: TextStyle(fontSize: 16)),
                  Text("📞 0912-345-6789", style: TextStyle(fontSize: 16)),
                  Text("📧 judyawonjuncris@gmail.com",
                      style: TextStyle(fontSize: 16)),
                  SizedBox(height: 20),
                  Center(
                    child: Text(
                      "Let’s Make Music Together!😊",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        fontStyle: FontStyle.italic,
                        color: Colors.green,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
