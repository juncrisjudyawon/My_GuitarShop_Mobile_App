import 'package:flutter/material.dart';
import 'package:my_grocery_app/profile.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  //store

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color.fromARGB(255, 57, 119, 16),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          //This is my header of drawer
          SizedBox(
            height: 250, //  Adjust this value to change background height
            child: DrawerHeader(
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 189, 189, 189),
              ),
              margin: EdgeInsets.zero,
              padding: EdgeInsets.zero,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pushNamed(context, '/profile');
                    },
                    child: CircleAvatar(
                      radius: 40,
                      backgroundColor: Colors.blue[300],
                      child: CircleAvatar(
                        radius: 60,
                        backgroundImage: AssetImage('lib/image/profile.jpg'),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Juncris Judyawon',
                    style: TextStyle(
                      fontSize: 18,
                      color: const Color.fromARGB(255, 255, 255, 255),
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  Text(
                    'judyawon@juncris.com',
                    style: TextStyle(
                      fontSize: 14,
                      color: const Color.fromARGB(255, 255, 255, 255),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),

//Drawes

          ListTile(
            leading: Icon(Icons.store, color: Colors.white),
            textColor: Colors.white,
            title: Text('Shop'),
            onTap: () {
              Navigator.pushNamed(context, '/shop');
            },
          ),
          ListTile(
            leading: Icon(Icons.article, color: Colors.white),
            textColor: Colors.white,
            title: Text('Newsstand'),
            onTap: () {
              Navigator.pushNamed(
                context,
                '/newsstand',
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.info, color: Colors.white),
            textColor: Colors.white,
            title: Text('Who we are'),
            onTap: () {
              Navigator.pushNamed(context, '/info');
            },
          ),
          ListTile(
            leading: Icon(Icons.person, color: Colors.white),
            textColor: Colors.white,
            title: Text('My Profile'),
            onTap: () {
              Navigator.pushNamed(context, '/profile');
            },
          ),
          ListTile(
            leading: Icon(Icons.shopping_cart, color: Colors.white),
            textColor: Colors.white,
            title: Text('Basket'),
            onTap: () {
              Navigator.pushNamed(context, '/cart');
            },
          ),
        ],
      ),
    );
  }
}
