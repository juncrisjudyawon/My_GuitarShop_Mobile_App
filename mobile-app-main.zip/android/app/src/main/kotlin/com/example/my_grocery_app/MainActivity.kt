package com.example.my_grocery_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
